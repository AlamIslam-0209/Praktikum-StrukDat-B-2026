mahasiswa = {
    "A001" : {
        "nama": 'Budi',
        "prodi": 'Informatika',
        'ipk': 3.45
    },
    "A002" : {
        "nama": 'siti',
        "prodi": 'Sistem Informasi',
        'ipk': 3.20
    },
    "A003" : {
        "nama": 'Andi',
        "prodi": 'Informatika',
        'ipk': 3.75
    }
}

# print(mahasiswa)

for nim in mahasiswa:
    x = nim["ipk"]
    print[x]
