mahasiswa = ("A001", "Budi", 'Informatika')

print(f"Mahasiswa: {mahasiswa}")

for i in mahasiswa:
    print(i)

""" 
alasan mengapa tuple tidak bisa di ubah karena 
tuple sendiri bersifat immutable atau unchangable 
alias tidak bisa diubah. biasanya tuple digunakan untuk operasi matematika
"""

